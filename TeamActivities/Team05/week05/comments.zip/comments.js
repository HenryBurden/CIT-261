const commentList = [
    {
        hikeName : 'Mesa Falls',
        typeFlag : 'hike',
        date : '10/24/2019',
        text : 'This is my comment.'
    }
];





class commentsView {
    renderCommentList(commentElement, commentList){
        for (comment in commentList){

        }
    }
}

export default class commentsController {
    constructor(commentId, commentType) {
        this.commentElement = document.getElementById(commentId);
        this.type = commentType;
    }
    showCommentsList() {
        const commentList = this.commentModel.getAllComments();
        // send the list of hikes and the element we would like those placed into to the view.
        this.commentView.renderHikeList(this.commentElement, commentList);
        // after the hikes have been rendered...add our listener
        this.addHikeListener();
    }
}

class commentsModel {
    getAllComments(){
        return commentList;
    }
}